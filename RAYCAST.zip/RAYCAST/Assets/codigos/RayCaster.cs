﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RayCaster : MonoBehaviour
{
    private GameObject objeto;
    private GameObject objeto1;
    private GameObject objeto2;

    private bool isCollision = false;
    private bool isCollision1 = false;
    private bool isCollision2 = false;

    private Color originalColor;

 


    void Update()
    {
        RaycastHit hit;
        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, transform.GetComponent<Camera>().farClipPlane))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * hit.distance, Color.yellow);
            if (objeto != null)
            {
                if (isCollision && objeto.name != hit.collider.gameObject.name)
                {
                    objeto.GetComponent<MeshRenderer>().materials[0].color = originalColor;
                    objeto = hit.collider.gameObject;
                    originalColor = objeto.GetComponent<MeshRenderer>().materials[0].color;
                    hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                    Debug.Log("Did Hit Another");
                }
            }
            if (!isCollision)
            {
                isCollision = true;
                objeto = hit.collider.gameObject;
                originalColor = objeto.GetComponent<MeshRenderer>().materials[0].color;
                hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                Debug.Log("Did Hit");
            }
        }
        else
        {
            if (isCollision)
            {
                isCollision = false;
                objeto.GetComponent<MeshRenderer>().materials[0].color = originalColor;
            }
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward) * transform.GetComponent<Camera>().farClipPlane, Color.white);
        }



        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward + Vector3.left + (1 / 3) * Vector3.up), out hit, transform.GetComponent<Camera>().farClipPlane))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward + Vector3.left + (1 / 3) * Vector3.up) * hit.distance, Color.yellow);
            if (objeto1 != null)
            {
                if (isCollision1 && objeto1.name != hit.collider.gameObject.name)
                {
                    objeto1.GetComponent<MeshRenderer>().materials[0].color = originalColor;
                    objeto1 = hit.collider.gameObject;
                    originalColor = objeto1.GetComponent<MeshRenderer>().materials[0].color;
                    hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                    Debug.Log("Did Hit Another");
                }
            }
            if (!isCollision1)
            {
                isCollision1 = true;
                objeto1 = hit.collider.gameObject;
                originalColor = objeto1.GetComponent<MeshRenderer>().materials[0].color;
                hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                Debug.Log("Did Hit");
            }
        }
        else
        {
            if (isCollision1)
            {
                isCollision1 = false;
                objeto1.GetComponent<MeshRenderer>().materials[0].color = originalColor;
            }
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward + Vector3.left + (1 / 3) * Vector3.up) * transform.GetComponent<Camera>().farClipPlane, Color.white);
        }





        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward + Vector3.right +(1/3)*Vector3.up), out hit, transform.GetComponent<Camera>().farClipPlane))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward + Vector3.right + (1 / 3) * Vector3.up) * hit.distance, Color.yellow);
            if (objeto2 != null)
            {
                if (isCollision2 && objeto2.name != hit.collider.gameObject.name)
                {
                    objeto2.GetComponent<MeshRenderer>().materials[0].color = originalColor;
                    objeto2 = hit.collider.gameObject;
                    originalColor = objeto2.GetComponent<MeshRenderer>().materials[0].color;
                    hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                    Debug.Log("Did Hit Another");
                }
            }
            if (!isCollision2)
            {
                isCollision2 = true;
                objeto2 = hit.collider.gameObject;
                originalColor = objeto2.GetComponent<MeshRenderer>().materials[0].color;
                hit.collider.gameObject.GetComponent<MeshRenderer>().materials[0].color = Color.red;
                Debug.Log("Did Hit");
            }
        }
        else
        {
            if (isCollision2)
            {
                isCollision2 = false;
                objeto2.GetComponent<MeshRenderer>().materials[0].color = originalColor;
            }
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward + Vector3.right + (1 / 3) * Vector3.up) * transform.GetComponent<Camera>().farClipPlane, Color.white);
        }


    }
}
